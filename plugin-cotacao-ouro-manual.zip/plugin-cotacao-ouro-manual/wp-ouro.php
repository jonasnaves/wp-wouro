<?php
/**
 * Plugin Name: WP Ouro
 * Description: Plugin para atualização de preços de produtos do WooCommerce de acordo com a cotação do ouro.
 * Version: 1.0
 * Author: Seu Nome
 * Author URI: https://seusite.com
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Adiciona as funções do plugin.
include_once( 'includes/wp-ouro-functions.php' );
include_once( 'admin/wp-ouro-options.php' );
var_dump( include_once( 'includes/wp-ouro-functions.php' ) );
var_dump( include_once( 'admin/wp-ouro-options.php' ) );

// Adiciona o JavaScript e o CSS do plugin.
add_action( 'admin_enqueue_scripts', 'wp_ouro_admin_enqueue_scripts' );
function wp_ouro_admin_enqueue_scripts() {
    wp_enqueue_script( 'wp-ouro', plugin_dir_url( __FILE__ ) . 'js/wp-ouro.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_style( 'wp-ouro', plugin_dir_url( __FILE__ ) . 'css/wp-ouro.css', array(), '1.0' );
}

// Adiciona a página de opções do plugin.
add_action( 'admin_menu', 'wp_ouro_add_options_page' );
function wp_ouro_add_options_page() {
    add_options_page( 'Cotação do ouro', 'Cotação do ouro', 'manage_options', 'wp_ouro', 'wp_ouro_options_page' );
}

// Registra as opções do plugin.
add_action( 'admin_init', 'wp_ouro_register_settings' );
function wp_ouro_register_settings() {
    register_setting( 'wp_ouro', 'wp_ouro_valor_ouro' );
    register_setting( 'wp_ouro', 'wp_ouro_categorias_atualizacao' );
    register_setting( 'wp_ouro', 'wp_ouro_lucro_adicional' );
    register_setting( 'wp_ouro', 'wp_ouro_lucro_adicional_tipo' );
    register_setting( 'wp_ouro', 'wp_ouro_produtos_excluidos' );
}

// Adiciona o shortcode para exibir o preço em ouro.
add_shortcode( 'ouro', 'wp_ouro_shortcode' );
function wp_ouro_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'produto' => '',
    ), $atts, 'ouro' );

    $produto = wc_get_product( $atts['produto'] );

    if ( ! $produto ) {
        return '';
    }

    $valor_ouro = get_option( 'wp_ouro_valor_ouro' );
    if ( ! $valor_ouro ) {
        return '';
    }

    $preco = $produto->get_price();
    $peso = $produto->get_weight();

    $lucro_adicional = get_option( 'wp_ouro_lucro_adicional', '' );
    $lucro_adicional_tipo = get_option( 'wp_ouro_lucro_adicional_tipo', '' );
    if ( $lucro_adicional && $lucro_adicional_tipo ) {
        if ( $lucro_adicional_tipo == 'porcentagem' ) {
            $lucro_adicional_valor = $preco * ( $lucro_adicional / 100 );
        } else {
            $lucro_adicional_valor = $lucro_adicional;
        }

        $preco += $lucro_adicional_valor;
    }

    $preco_em_ouro = $preco / $peso / $valor_ouro;

return number_format( $preco_em_ouro, 2 ) . ' g de ouro';

}

// Adiciona o botão para verificar produtos com peso 0.
add_action( 'woocommerce_product_options_weight', 'wp_ouro_add_check_weight_button' );
function wp_ouro_add_check_weight_button() {
echo '<button type="button" class="button" id="wp_ouro_check_weight_button">Verificar produtos com peso 0</button>';
}

// Adiciona o JavaScript para verificar produtos com peso 0.
add_action( 'admin_footer', 'wp_ouro_check_weight_button_js' );
function wp_ouro_check_weight_button_js() {
?>
<script>
jQuery(document).ready(function($) {
$('#wp_ouro_check_weight_button').on('click', function() {
$.ajax({
url: '<?php echo esc_url( admin_url( "admin-ajax.php" ) ); ?>',
type: 'POST',
data: {
action: 'wp_ouro_check_weight_products',
},
beforeSend: function() {
$('#wp_ouro_check_weight_button').after('<span class="wp-ouro-spinner"></span>');
},
success: function(response) {
var products = JSON.parse(response);
var html = '<ul>';
                    if (products.length > 0) {
                        for (var i = 0; i < products.length; i++) {
                            html += '<li><a href="' + products[i].permalink + '" target="_blank">' + products[i].name + '</a></li>';
                        }
                    } else {
                        html += '<li>Nenhum produto encontrado.</li>';
                    }

                    html += '</ul>';

                    $('#wp_ouro_check_weight_button').siblings('.wp-ouro-spinner').remove();
                    $('#wp_ouro_check_weight_button').after(html);
                },
                error: function(response) {
                    console.log(response);
                }
            });
        });
    });
</script>
<?php
}

// Adiciona a função para verificar produtos com peso 0.
add_action( 'wp_ajax_wp_ouro_check_weight_products', 'wp_ouro_check_weight_products' );
function wp_ouro_check_weight_products() {
$products = array();
$args = array(
'post_type' => 'product',
'posts_per_page' => -1,
'meta_query' => array(
array(
'key' => '_weight',
'value' => '0',
'compare' => '=',
'type' => 'NUMERIC',
),
),
);
$query = new WP_Query( $args );

if ( $query->have_posts() ) {
    while ( $query->have_posts() ) {
        $query->the_post();

        $product_id = get_the_ID();
        $product = wc_get_product( $product_id );
        $products[] = array(
            'name' => get_the_title(),
            'permalink' => get_permalink(),
        );
    }
}

wp_reset_postdata();

echo json_encode( $products );

wp_die();
}

