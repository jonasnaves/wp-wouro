<?php

// Atualiza os preços dos produtos com base na cotação do ouro
add_action
('wp_ouro_atualizar_precos', 'wp_ouro_atualizar_precos');
function wp_ouro_atualizar_precos() {
    // Verifica se a cotação do ouro foi definida
    $valor_ouro = get_option( 'wp_ouro_valor_ouro', 0 );
    if ( empty( $valor_ouro ) ) {
        wp_send_json_error( 'A cotação do ouro não foi definida.' );
        wp_die();
    }

    // Verifica se as categorias de atualização foram definidas
    $categorias_atualizacao = get_option( 'wp_ouro_categorias_atualizacao', array() );
    if ( empty( $categorias_atualizacao ) ) {
        wp_send_json_error( 'As categorias de atualização não foram definidas.' );
        wp_die();
    }

    // Atualiza os preços dos produtos das categorias selecionadas
    $produtos_atualizados = 0;
    $produtos = get_posts( array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $categorias_atualizacao,
                'operator' => 'IN'
            )
        )
    ) );

    foreach ( $produtos as $produto ) {
        // Verifica se o produto tem peso definido
        $peso = get_post_meta( $produto->ID, '_weight', true );
        if ( empty( $peso ) ) {
            continue;
        }

        // Calcula o novo preço com base na cotação do ouro e no peso do produto
        $preco_atual = get_post_meta( $produto->ID, '_regular_price', true );
        $valor_adicional = get_post_meta( $produto->ID, '_ouro_valor_adicional', true );
        if ( empty( $valor_adicional ) ) {
            $valor_adicional = 0;
        }

        if ( strpos( $valor_adicional, '%' ) !== false ) {
            // Valor adicional em porcentagem
            $valor_adicional_porcentagem = floatval( str_replace( '%', '', $valor_adicional ) ) / 100;
            $preco_novo = ( $valor_ouro * $peso * ( 1 + $valor_adicional_porcentagem ) );
        } else {
            // Valor adicional em valor fixo
            $preco_novo = ( $valor_ouro * $peso + floatval( $valor_adicional ) );
        }

        // Atualiza o preço do produto
        if ( $preco_atual != $preco_novo ) {
            update_post_meta( $produto->ID, '_regular_price', $preco_novo );
            update_post_meta( $produto->ID, '_price', $preco_novo );
            $produtos_atualizados++;
        }
    }

    // Retorna a mensagem de sucesso
    wp_send_json_success( 'Atualização concluída. ' . $produtos_atualizados . ' produtos atualizados.' );
    wp_die();
}

// Verifica os produtos das categorias selecionadas que estão sem peso
add_action( 'wp_ajax_wp_ouro_verificar_produtos_sem_peso', 'wp_ouro_verificar_produtos_sem_peso' );
function wp_ouro_verificar_produtos_sem_peso() {
    // Verifica se as categorias de atualização foram definidas
    $categorias_atualizacao = get_option( 'wp_ouro_categorias_atualizacao', array() );
    if ( empty( $categorias_atualizacao ) ) {
        wp_send_json_error( 'As categorias de atualização não foram definidas.' );
        wp_die();
    }

    // Verifica se há produtos sem peso nas categorias selecionadas
    $produtos_sem_peso = array();
    $produtos = get_posts( array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $categorias_atualizacao,
                'operator' => 'IN'
            )
        ),
        'meta_query' => array(
            array(
                'key' => '_weight',
                'value' => '',
                'compare' => 'LIKE'
            )
        )
    ) );

    foreach ( $produtos as $produto ) {
        $produtos_sem_peso[] = array(
            'nome' => $produto->post_title,
            'link' => get_permalink( $produto->ID )
        );
    }

    // Retorna a lista de produtos sem peso
    if ( ! empty( $produtos_sem_peso ) ) {
        wp_send_json_success( $produtos_sem_peso );
    } else {
        wp_send_json_error( 'Não há produtos sem peso nas categorias selecionadas.' );
    }
    wp_die();
}

// Adiciona os scripts e estilos do plugin
add_action( 'admin_enqueue_scripts', 'wp_ouro_adicionar_scripts_estilos' );
function wp_ouro_adicionar_scripts_estilos() {
    wp_enqueue_script( 'wp-ouro', plugin_dir_url( __FILE__ ) . 'wp-ouro.js', array( 'jquery' ), '1.0.0', true );
    wp_enqueue_style( 'wp-ouro', plugin_dir_url( __FILE__ ) . 'wp-ouro.css', array(), '1.0.0', 'all' );
}

