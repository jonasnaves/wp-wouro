jQuery( document ).ready( function( $ ) {
    // Atualiza os preços dos produtos
    $( '#wp-ouro-atualizar-precos' ).on( 'click', function() {
        var $button = $( this );
        $button.attr( 'disabled', true );
        $button.addClass( 'wp-ouro-loading' );

        $.ajax( {
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wp_ouro_atualizar_precos'
            },
            success: function( response ) {
                if ( response.success ) {
                    alert( response.data );
                } else {
                    alert( response.data );
                }
                $button.attr( 'disabled', false );
                $button.removeClass( 'wp-ouro-loading' );
            },
            error: function() {
                alert( 'Erro ao atualizar os preços dos produtos.' );
                $button.attr( 'disabled', false );
                $button.removeClass( 'wp-ouro-loading' );
            }
        } );
    } );

    // Verifica os produtos sem peso
    $( '#wp-ouro-verificar-produtos-sem-peso' ).on( 'click', function() {
        var $button = $( this );
        $button.attr( 'disabled', true );
        $button.addClass( 'wp-ouro-loading' );

        $.ajax( {
            url: ajaxurl,
            type: 'POST,
            data: {
                action: 'wp_ouro_verificar_produtos_sem_peso'
            },
            success: function( response ) {
                if ( response.success ) {
                    var $table = $( '<table>' );
                    $table.append( '<thead><tr><th>Produto</th><th>Link</th></tr></thead>' );
                    var $tbody = $( '<tbody>' );
                    for ( var i = 0; i < response.data.length; i++ ) {
                        var $tr = $( '<tr>' );
                        var $tdNome = $( '<td>' );
                        $tdNome.text( response.data[i].nome );
                        $tr.append( $tdNome );
                        var $tdLink = $( '<td>' );
                        var $link = $( '<a>' );
                        $link.attr( 'href', response.data[i].link );
                        $link.attr( 'target', '_blank' );
                        $link.text( 'Abrir link' );
                        $tdLink.append( $link );
                        $tr.append( $tdLink );
                        $tbody.append( $tr );
                    }
                    $table.append( $tbody );
                    $( '#wp-ouro-produtos-sem-peso' ).html( $table );
                } else {
                    alert( response.data );
                }
                $button.attr( 'disabled', false );
                $button.removeClass( 'wp-ouro-loading' );
            },
            error: function() {
                alert( 'Erro ao verificar os produtos sem peso.' );
                $button.attr( 'disabled', false );
                $button.removeClass( 'wp-ouro-loading' );
            }
        } );
    } );
} );

