<h1>Cotação do ouro</h1>

<form method="post" action="options.php">
    <?php settings_fields( 'wp_ouro' ); ?>
    <?php do_settings_sections( 'wp_ouro' ); ?>

    <table class="form-table">
        <tbody>
            <tr>
                <th scope="row"><label for="wp_ouro_valor_ouro">Valor do ouro:</label></th>
                <td><input name="wp_ouro_valor_ouro" type="text" id="wp_ouro_valor_ouro" value="<?php echo esc_attr( get_option( 'wp_ouro_valor_ouro', '' ) ); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row"><label for="wp_ouro_categorias_atualizacao">Categorias de atualização:</label></th>
                <td><?php wp_dropdown_categories( array( 'name' => 'wp_ouro_categorias_atualizacao[]', 'taxonomy' => 'product_cat', 'selected' => esc_attr(implode(',', get_option('wp_ouro_categorias_atualizacao', array()))), 'class' => 'regular-text', 'multiple' => 'multiple' ) ); ?></td>


            </tr>
            <tr>
                <th scope="row"><label for="wp_ouro_lucro_adicional">Lucro adicional:</label></th>
                <td>
                    <input name="wp_ouro_lucro_adicional" type="text" id="wp_ouro_lucro_adicional" value="<?php echo esc_attr( get_option( 'wp_ouro_lucro_adicional', '' ) ); ?>" class="regular-text">
                    <select name="wp_ouro_lucro_adicional_tipo" id="wp_ouro_lucro_adicional_tipo">
                        <option value="porcentagem"<?php selected( get_option( 'wp_ouro_lucro_adicional_tipo', '' ), 'porcentagem' ); ?>>%</option>
                        <option value="valor"<?php selected( get_option( 'wp_ouro_lucro_adicional_tipo', '' ), 'valor' ); ?>>R$</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="wp_ouro_produtos_excluidos">Produtos excluídos:</label></th>
                <td><textarea name="wp_ouro_produtos_excluidos" id="wp_ouro_produtos_excluidos" rows="5" cols="50" class="large-text"><?php echo esc_html( get_option( 'wp_ouro_produtos_excluidos', '' ) ); ?></textarea></td>
            </tr>
        </tbody>
    </table>

    <?php submit_button(); ?>
</form>
<?php

// Adiciona a página de configurações do plugin no menu do WordPress
add_action( 'admin_menu', 'wp_ouro_adicionar_pagina_configuracoes' );
function wp_ouro_adicionar_pagina_configuracoes() {
    add_menu_page(
        'WP Ouro',
        'WP Ouro',
        'manage_options',
        'wp_ouro_settings',
        'wp_ouro_pagina_configuracoes',
        'dashicons-chart-line',
        90
    );
}

// Adiciona os campos de configurações do plugin
add_action( 'admin_init', 'wp_ouro_adicionar_campos_configuracoes' );
function wp_ouro_adicionar_campos_configuracoes() {
    add_settings_section(
        'wp_ouro_cotacao_ouro',
        'Cotação do Ouro',
        'wp_ouro_secao_cotacao_ouro',
        'wp_ouro_settings'
    );

    add_settings_field(
        'wp_ouro_valor_ouro',
        'Valor do Ouro',
        'wp_ouro_campo_valor_ouro',
        'wp_ouro_settings',
        'wp_ouro_cotacao_ouro'
    );

    add_settings_field(
        'wp_ouro_categorias_atualizacao',
        'Categorias de Atualização',
        'wp_ouro_campo_categorias_atualizacao',
        'wp_ouro_settings',
        'wp_ouro_cotacao_ouro'
    );

    register_setting( 'wp_ouro_settings', 'wp_ouro_valor_ouro' );
    register_setting( 'wp_ouro_settings', 'wp_ouro_categorias_atualizacao' );
}

// Define o conteúdo da seção "Cotação do Ouro"
function wp_ouro_secao_cotacao_ouro() {
    echo 'Defina a cotação atual do ouro e as categorias de produtos que devem ser atualizadas automaticamente:';
}

// Define o campo de valor do ouro
function wp_ouro_campo_valor_ouro() {
    $valor_ouro = get_option( 'wp_ouro_valor_ouro', 0 );
    echo '<input type="number" step="0.01" min="0" name="wp_ouro_valor_ouro" value="' . esc_attr( $valor_ouro ) . '" />';
}

// Define o campo de categorias de atualização
function wp_ouro_campo_categorias_atualizacao() {
    $categorias_atualizacao = get_option( 'wp_ouro_categorias_atualizacao', array() );
    $categorias = get_terms( 'product_cat', array( 'hide_empty' => false ) );

    echo '<select multiple name="wp_ouro_categorias_atualizacao[]">';
    foreach ( $categorias as $categoria ) {
        $selecionado = in_array( $categoria->term_id, $categorias_atualizacao ) ? 'selected' : '';
        echo '<option value="' . esc_attr( $categoria->term_id ) . '" ' . $selecionado . '>' . esc_html( $categoria->name ) . '</option>';
    }
    echo '</select>';
}
